/******************************************************************************
Lista duplamente ligada
*******************************************************************************/

#include <stdio.h>

struct itm {
	int codigo;
    char nome[30];
    struct itm *anterior;
    struct itm *proximo;
} typedef pessoa;

struct {
    pessoa *inicio;
} typedef lista;

void adicionar(lista *p){
    pessoa *novo = (pessoa*)malloc(sizeof(pessoa));    
    printf("\nInforme o codigo:");
    scanf("%i", &novo->codigo);
	printf("\nInforme o nome:");
    scanf("%s", &novo->nome);
    novo->proximo = NULL;
    if(p->inicio==NULL){
        novo->anterior=NULL;
        p->inicio = novo;
    } else {
        pessoa *aux = p->inicio;
        while(aux->proximo != NULL){
            aux = aux->proximo;
        }
        aux->proximo = novo;
        novo->anterior = aux;
        printf("\n aux=%x novo=%x ", aux->proximo, novo->anterior);
    }
}

void listar(lista *p){
    if(p->inicio==NULL){
        printf("\nLista Vazia !!!");
    } else {
        pessoa *aux = p->inicio;
        do{
            printf("\ncodigo=%i nome=%s",aux->codigo, aux->nome);
            aux = aux->proximo;
        } while(aux != NULL);
    }
}


void remover(lista *p, int codigo){
    if(p->inicio==NULL){
        printf("\nLista Vazia !!!");
    } else {
        pessoa *aux = p->inicio;
        while(aux != NULL){
        	//strcmp(nome1, nome) == 0
            if(aux->codigo == codigo){
                if(aux == p->inicio) { //quando for o primeiro item
                    p->inicio = aux->proximo;
                } else { //quando for qualquer item 
                    pessoa *aux2 = aux->anterior;
                    pessoa *aux3 = aux->proximo;
                    aux2->proximo = aux3;
                    aux3->anterior = aux2;
                    
                    //aux->anterior->proximo = aux->proximo;
                    //aux->proximo->anterior = aux->anterior;
                }    
                free(aux);
                printf("\ncodigo removido %i", codigo);
                break;
                // APAGAR 
            }
            aux = aux->proximo;
        }
    } 
}



int main()
{
    lista  l1 = {NULL};
    
    adicionar(&l1);
    adicionar(&l1);
    adicionar(&l1);
   
    listar(&l1);
 
    remover(&l1, 2);
      listar(&l1);
    remover(&l1, 3);
      listar(&l1);
    adicionar(&l1);
    remover(&l1, 1);
      listar(&l1);

    return 0;
}


